(function() {
  'use strict';

  angular
    .module('npng', ['ngTouch', 'ngRoute', 'ui.bootstrap', 'duScroll']);

})();
